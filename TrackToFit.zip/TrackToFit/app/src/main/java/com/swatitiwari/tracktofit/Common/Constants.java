package com.swatitiwari.tracktofit.Common;

public class Constants {

    public static final String USER = "user";



    public static final String DATE_FORMAT = "dd MMM YYYY hh:mm a";
}
