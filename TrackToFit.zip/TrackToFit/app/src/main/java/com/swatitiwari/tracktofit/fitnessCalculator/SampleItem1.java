package com.swatitiwari.tracktofit.fitnessCalculator;

public class SampleItem1 {
	private String mob;

	public SampleItem1(String mob) {
		this.mob = mob;
	}

	public SampleItem1() {
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}
}
