package com.swatitiwari.tracktofit.fitnessCalculator;

public class SampleItem2 {
	private String mob, name;

	public SampleItem2() {
	}

	public SampleItem2(String mob, String name) {
		this.mob = mob;
		this.name = name;
	}

	public String getMob() {
		return mob;
	}

	public void setMob(String mob) {
		this.mob = mob;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
