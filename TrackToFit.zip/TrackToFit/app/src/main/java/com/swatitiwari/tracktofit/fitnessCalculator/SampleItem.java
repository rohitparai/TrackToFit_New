package com.swatitiwari.tracktofit.fitnessCalculator;

public class SampleItem {
	private String food;

	public SampleItem() {
	}

	public SampleItem(String food) {
		this.food = food;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}
}