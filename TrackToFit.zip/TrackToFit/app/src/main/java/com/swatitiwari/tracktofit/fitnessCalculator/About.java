package com.swatitiwari.tracktofit.fitnessCalculator;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.swatitiwari.tracktofit.R;

public class About extends AppCompatActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
		//getSupportActionBar().hide();
	}
}
